<html>
<head>
	<title>Comming Soon</title>
	<link rel="stylesheet" type="text/css" href="css/commingsoon.css">
</head>
<body>
<div class="body">
	<div class="body-container">
		<div class="body-text2">
			We are coming soon...
		</div>
	</div>
</div>
<div class="footer">
	<div class="footer-text">All copyright resevered by HexaParity</div>
</div>
</body>
</html>