<html>
<head>
	<title>Comming Soon</title>
	<link rel="stylesheet" type="text/css" href="css/commingsoon.css">
</head>
<body>
<div class="body">
	<div class="body-container">
		<div class="body-text2">
			Site Under Construction....
		</div>
	</div>
</div>
<div class="footer">
	<div class="footer-text">All Copyright Resevered by ClickForFly</div>
</div>
</body>
</html>